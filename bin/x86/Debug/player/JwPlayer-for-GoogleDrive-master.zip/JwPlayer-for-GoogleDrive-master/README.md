# JwPlayer-for-GoogleDrive (not work
A Batter Way to Direct Google Drive Video<br>
1.Please Get your Video OpenID in Google Drive.<br>
  ex. https://drive.google.com/open?id=0B757HvrhbFeienJaWnFfWGtQYUU<br>
      so the ID is 0B757HvrhbFeienJaWnFfWGtQYUU<br>
2.Put ID after URL.<br>
  ex. https://localhost:80/index?0B757HvrhbFeienJaWnFfWGtQYUU<br>
3.Enjoy!<br>
