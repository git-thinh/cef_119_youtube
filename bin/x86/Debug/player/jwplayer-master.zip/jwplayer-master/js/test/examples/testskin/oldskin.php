<?
Header( "Location: testskin.xml" ); 
?> 